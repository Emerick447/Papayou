/* ==========================================================
   PAPAYOU V8 - SCRIPT.JS
   PARTIE 1
========================================================== */
let playerCards = {};
let players = [];
let rounds = [];
let usedCards = [];

const TOTAL = 250;

const config = document.getElementById("config");
const playersPage = document.getElementById("players");
const game = document.getElementById("game");

const playersList = document.getElementById("playersList");
const scores = document.getElementById("scores");
const scoreTable = document.getElementById("scoreTable");
const leader = document.getElementById("leader");
const ranking = document.getElementById("ranking");

document.getElementById("btnConfig").onclick = createPlayersInputs;
document.getElementById("btnStart").onclick = startGame;
document.getElementById("btnCalculate").onclick = calculateLastPlayer;
document.getElementById("btnRound").onclick = validateRound;
document.getElementById("btnUndo").onclick = undoRound;
document.getElementById("btnFinish").onclick = finishGame;


/* ==========================================================
   ETAPE 1
========================================================== */

function createPlayersInputs(){

    const nb = Number(document.getElementById("nbPlayers").value);

    playersList.innerHTML = "";

    for(let i=0;i<nb;i++){

        playersList.innerHTML += `
            <input
                type="text"
                id="player${i}"
                value="Joueur ${i+1}">
        `;

    }

    config.classList.add("hidden");
    playersPage.classList.remove("hidden");

}


/* ==========================================================
   ETAPE 2
========================================================== */

function startGame(){

    players = [];

    const nb = Number(document.getElementById("nbPlayers").value);

    for(let i=0;i<nb;i++){

        players.push({

            name:document.getElementById("player"+i).value,

            total:0

        });

    }

    playersPage.classList.add("hidden");

    game.classList.remove("hidden");

    createScoreInputs();

    drawTable();

}


/* ==========================================================
   CHAMPS DES SCORES
========================================================== */

function createScoreInputs(){

    scores.innerHTML="";

    playerCards={};

    for(let i=0;i<players.length-1;i++){

        scores.innerHTML += `

            <div class="scoreRow">

                <label>${players[i].name}</label>

                <input
                    type="text"
                    value="0"
                    class="scoreInput"
                    id="score${i}">

            </div>

        `;

    }

    scores.innerHTML += `

        <div class="scoreRow">

            <label>${players.at(-1).name}</label>

            <input
                type="number"
                id="lastScore"
                disabled>

        </div>

    `;

}


/* ==========================================================
   CALCUL AUTOMATIQUE
========================================================== */

function calculateLastPlayer(){

    let sum = 0;

    for(let i = 0; i < players.length - 1; i++){

        const input = document.getElementById("score"+i);

        const text = input.value;

        const value = text
            .split("+")
            .map(v => Number(v.trim()) || 0)
            .reduce((a,b) => a+b, 0);

        // Remplace "5+58+..." par "63"
        input.value = value;

        sum += value;
    }

    document.getElementById("lastScore").value = TOTAL - sum;

}


/* ==========================================================
   VALIDER UNE MANCHE
========================================================== */

function validateRound(){

    if(document.getElementById("lastScore").value===""){
        calculateLastPlayer();
    }

    let row=[];
    let sum=0;

    for(let i=0;i<players.length-1;i++){

        const text=document.getElementById("score"+i).value;

        const value=text
            .split("+")
            .map(v=>Number(v.trim())||0)
            .reduce((a,b)=>a+b,0);

        row.push(value);
        sum+=value;

    }

    const last=Number(document.getElementById("lastScore").value)||0;

    if(sum+last!==TOTAL){

        alert("Le total doit être égal à "+TOTAL+" points.");
        return;

    }

    row.push(last);

    rounds.push(row);

    for(let i=0;i<players.length;i++){

        players[i].total+=row[i];

    }

    usedCards=[];

    drawTable();

    createScoreInputs();

}

/* ==========================================================
   TABLEAU
========================================================== */

function drawTable(){

    let html="<tr>";

    html+="<th>Joueur</th>";

    for(let i=0;i<rounds.length;i++){

        html+=`<th>M${i+1}</th>`;

    }

    html+="<th>Total</th>";

    html+="</tr>";

    players.forEach((player,index)=>{

        html+="<tr>";

        html+=`<td>${player.name}</td>`;

        rounds.forEach(round=>{

            html+=`<td>${round[index]}</td>`;

        });

        html+=`<td><b>${player.total}</b></td>`;

        html+="</tr>";

    });

    scoreTable.innerHTML=html;

    updateLeader();

}


/* ==========================================================
   LEADER
========================================================== */

function updateLeader(){

    const best=[...players].sort(

        (a,b)=>a.total-b.total

    )[0];

    leader.innerHTML=
        "🏅 "+best.name+
        " ("+best.total+" pts)";

}

/* ============================
   LA PARTIE 2 CONTINUERA ICI
============================= */
/* ==========================================================
   PAPAYOU V8 - SCRIPT.JS
   PARTIE 2
========================================================== */

/***************
 * Annuler
 ***************/
function undoRound(){

    if(rounds.length===0) return;

    const last=rounds.pop();

    for(let i=0;i<players.length;i++){

        players[i].total-=last[i];

    }

    drawTable();

}


/***************
 * Classement final
 ***************/
function finishGame(){

    let list=[...players];

    list.sort((a,b)=>a.total-b.total);


    let html="<h2>🏆 Classement final</h2>";


    list.forEach((p,i)=>{

        html+=`
        <p>
            ${i+1}. <b>${p.name}</b>
            - ${p.total} points
        </p>
        `;

    });


    // Boutons sous le classement
    html += `
        <button id="btnExport">
            📄 Export PDF
        </button>

        <button id="btnRestart">
            🔄 Recommencer
        </button>
    `;


    ranking.innerHTML = html;


    // Export PDF
    document.getElementById("btnExport").onclick = exportPDF;


    // Recharger la partie
    document.getElementById("btnRestart").onclick = function(){

        location.reload();

    };

}


/****************************************************
                CARTES VIRTUELLES
****************************************************/

const cardsModal=document.getElementById("cardsModal");
const cardsGrid=document.getElementById("cardsGrid");

let currentInput=null;


/***************
 * Création des cartes
 ***************/
function createCards(){

    cardsGrid.innerHTML="";

    for(let i=1;i<=20;i++){

        const card=document.createElement("button");

        card.className="cardButton";

        card.textContent=i;

        if(usedCards.includes(i)){

            card.disabled=true;
            card.classList.add("used");

        }else{

            card.onclick=()=>selectCard(i);

        }

        cardsGrid.appendChild(card);

    }

    const c40=document.createElement("button");

    c40.className="cardButton special";

    c40.textContent="40";

    if(usedCards.includes(40)){

        c40.disabled=true;
        c40.classList.add("used");

    }else{

        c40.onclick=()=>selectCard(40);

    }

    cardsGrid.appendChild(c40);

}

/***************
 * Ouvrir les cartes
 ***************/
function openCards(inputId){

    currentInput=inputId;

    createCards();

    cardsModal.classList.remove("hidden");

}


/***************
 * Fermer
 ***************/
document.getElementById("closeCards").onclick=function(){

    cardsModal.classList.add("hidden");

};


/***************
 * Choix d'une carte
 ***************/
function selectCard(value){

    const input=document.getElementById(currentInput);

    if(!input) return;

    if(!playerCards[currentInput]){
        playerCards[currentInput]=[];
    }

    playerCards[currentInput].push(value);

    input.value = playerCards[currentInput].join(" + ");

    usedCards.push(value);

    createCards();

}

/****************************************************
   Ajout du bouton Cartes à chaque ligne
****************************************************/

const oldCreate=createScoreInputs;

createScoreInputs=function(){

    oldCreate();

    const rows=document.querySelectorAll(".scoreRow");

    rows.forEach((row,index)=>{

        if(index===players.length-1) return;

        const b=document.createElement("button");

        b.textContent="🎴 Cartes";

        b.type="button";

        b.onclick=function(){

            openCards("score"+index);

        };

        row.appendChild(b);

    });

};





/****************************************************
   Fermeture de la fenêtre en cliquant à côté
****************************************************/

cardsModal.onclick=function(e){

    if(e.target===cardsModal){

        cardsModal.classList.add("hidden");

    }

};


/****************************************************
   Calcul dès le début
****************************************************/

setTimeout(function(){

    if(document.getElementById("lastScore")){

        calculateLastPlayer();

    }

},100);

function exportPDF(){

    const { jsPDF } = window.jspdf;

    const doc = new jsPDF("landscape");


    /*
        TITRE
    */

    doc.setFontSize(20);

    doc.text(
        "Scores Papayou",
        14,
        18
    );


    doc.setFontSize(12);

    doc.text(
        "Résultat de la partie",
        14,
        27
    );



    /*
        TABLEAU DES SCORES
        Joueurs = colonnes
        Manches = lignes
    */


    const head = [["Manche"]];


    players.forEach(player=>{

        head[0].push(player.name);

    });


    head[0].push("Total");



    const body = [];



    rounds.forEach((round,index)=>{


        const row = [];

        row.push("Manche " + (index + 1));


        let totalManche = 0;



        round.forEach(score=>{

            row.push(score);

            totalManche += score;

        });



        row.push(totalManche);


        body.push(row);


    });




    /*
        LIGNE TOTAUX
    */


    const totalRow = ["Total"];


    players.forEach(player=>{

        totalRow.push(player.total);

    });



    totalRow.push(

        players.reduce(
            (total,p)=>total+p.total,
            0
        )

    );



    body.push(totalRow);




    doc.autoTable({

        head: head,

        body: body,

        startY:35,

        theme:"grid",


        headStyles:{

            fillColor:[37,99,235],

            textColor:255,

            halign:"center",

            fontStyle:"bold"

        },


        bodyStyles:{

            halign:"center"

        },


        styles:{

            fontSize:11

        },


        didParseCell(data){


            if(
                data.row.index === body.length-1
            ){

                data.cell.styles.fontStyle="bold";

            }


        }


    });





    /*
        CLASSEMENT FINAL
    */


    let y = doc.lastAutoTable.finalY + 15;



    doc.setFontSize(16);


    doc.text(

        "Classement final",

        14,

        y

    );



    y += 10;



    const classement = [...players].sort(

        (a,b)=>a.total-b.total

    );



    doc.setFontSize(12);



    classement.forEach((player,index)=>{


        doc.text(

            (index+1)
            + ". "
            + player.name
            + " - "
            + player.total
            + " points",

            18,

            y

        );


        y += 8;


    });





    /*
        CREATION DU CAMEMBERT
    */


    const canvas = document.createElement("canvas");


    canvas.width = 500;

    canvas.height = 500;



    const ctx = canvas.getContext("2d");



    new Chart(ctx, {


        type:"pie",


        data:{


            labels: players.map(
                p=>p.name
            ),



            datasets:[{


                data: players.map(
                    p=>p.total
                )


            }]


        },



        options:{


            responsive:false,


            plugins:{


                legend:{


                    position:"bottom"


                },


                title:{


                    display:true,


                    text:"Répartition des points"


                }


            }


        },


        plugins:[{


            id:"export",


            afterRender(chart){


                const image =
                    chart.toBase64Image();



                /*
                    NOUVELLE PAGE PDF
                */


                doc.addPage();



                doc.setFontSize(18);



                doc.text(

                    "Répartition des points",

                    14,

                    20

                );



                doc.addImage(

                    image,

                    "PNG",

                    55,

                    35,

                    120,

                    120

                );



                doc.save(
                    "Papayou_Scores.pdf"
                );


            }


        }]


    });


}

function createScorePieChart(callback){

    const canvas = document.createElement("canvas");

    canvas.width = 500;
    canvas.height = 500;

    const ctx = canvas.getContext("2d");


    new Chart(ctx, {

        type:"pie",

        data:{

            labels: players.map(p => p.name),

            datasets:[{

                data: players.map(p => p.total)

            }]

        },

        options:{

            responsive:false,

            plugins:{

                legend:{

                    position:"bottom"

                }

            }

        },

        plugins:[{

            id:"done",

            afterRender(chart){

                callback(
                    chart.toBase64Image()
                );

            }

        }]

    });

}
/* =======================
      FIN DU SCRIPT
======================= */